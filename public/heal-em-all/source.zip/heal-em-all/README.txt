Heal'em All — complete corresponding source

Original commit: 66950cda39d2b91f114dcf1a0b0307972f24a68f
Code and adaptation: GPL-3.0-only. Art: CC-BY-4.0. Engine/utilities: MIT.
See public/heal-em-all/NOTICE.txt and the full license files.

All 48 original CoffeeScript modules are under vendor/heal-em-all-original/
upstream/app/scripts/game/. The original generated JS and complete engine,
maps, spritesheets and art are retained there. No compiler or package install
is required to reproduce the adapted runtime:

  python3 scripts/heal-em-all/adapt.py
  python3 scripts/heal-em-all/verify-sources.py

The HTML game runs from public/heal-em-all/ on any ordinary static server.
Its bridge and React host are handwritten source. The host imports the
Playgarden GameProps shape (level, paused, resetToken, freshStart, hintToken,
undoToken, onComplete, onStatus). All changed engine/game seams are described
in adapt.py. No audio, remote fonts or analytics are used.
